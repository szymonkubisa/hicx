<template>
  <div class="min-h-100">
    <router-view />
  </div>
</template>
