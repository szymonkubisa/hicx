<template>
  <div class="home">
    <a-layout id="components-layout-demo-top-side">
      <a-layout-header class="header">
        <a-menu
          theme="dark"
          mode="horizontal"
          :defaultSelectedKeys="['1']"
          :style="{ lineHeight: '64px' }"
        >
          <a-menu-item key="0" class="p-0">
            <a href="javascript:;" class="ant-dropdown-link">
              <img
                alt="Vue logo"
                src="../assets/hicx-logo.svg"
                class="logo"
              /> </a
          ></a-menu-item>
          <a-menu-item key="1">
            <a href="javascript:;" class="ant-dropdown-link">
              <a-icon type="global" />Actions <a-icon type="down" /> </a
          ></a-menu-item>
          <a-menu-item key="2"
            ><a href="javascript:;" class="ant-dropdown-link">
              <a-icon type="global" />Requests <a-icon type="down" /> </a
          ></a-menu-item>
          <a-menu-item key="3"
            ><a href="javascript:;" class="ant-dropdown-link">
              <a-icon type="global" />Suppliers <a-icon type="down" /> </a
          ></a-menu-item>
          <a-menu-item key="4"
            ><a href="javascript:;" class="ant-dropdown-link">
              <a-icon type="global" />Initiatives <a-icon type="down" /> </a
          ></a-menu-item>
          <a-menu-item key="5"
            ><a href="javascript:;" class="ant-dropdown-link">
              <a-icon type="global" />Contracts <a-icon type="down" /> </a
          ></a-menu-item>
          <a-menu-item key="6"
            ><a href="javascript:;" class="ant-dropdown-link">
              <a-icon type="global" />SRM <a-icon type="down" /> </a
          ></a-menu-item>
          <a-menu-item key="7"
            ><a href="javascript:;" class="ant-dropdown-link">
              <a-icon type="global" />Transactions <a-icon type="down" /> </a
          ></a-menu-item>
          <a-menu-item key="7" class="ml-auto p-0"
            ><a href="javascript:;"> <a-icon type="user" /> </a
          ></a-menu-item>
        </a-menu>
      </a-layout-header>
      <a-layout-content style="padding: 0 50px">
        <a-row type="flex" justify="space-between" align="middle">
          <div>
            <a-breadcrumb style="margin: 16px 0">
              <a-breadcrumb-item><a-icon type="home" /> Home</a-breadcrumb-item>
              <a-breadcrumb-item>Actions</a-breadcrumb-item>
            </a-breadcrumb>
            <h1>Actions</h1>
          </div>

          <a-dropdown>
            <a-menu slot="overlay">
              <a-menu-item key="1"
                ><a-icon type="thunderbolt" />New Action</a-menu-item
              >
              <a-menu-item key="2"
                ><a-icon type="bars" />New Action Plan</a-menu-item
              >
            </a-menu>
            <a-button type="primary">
              <a-icon type="plus" />Create New</a-button
            >
          </a-dropdown>
        </a-row>

        <a-layout style="padding: 14px 0 0; background: #fff">
          <a-layout-content :style="{ padding: '0 0', minHeight: '280px' }">
            <a-tabs defaultActiveKey="1">
              <a-tab-pane tab="Actions" key="1">
                <a-row
                  type="flex"
                  justify="space-between"
                  style="padding: 0 16px"
                >
                  <h2>Actions</h2>
                  <a-input-search
                    placeholder="Search Actions"
                    style="width: 200px"
                  />
                </a-row>

                <a-table
                  :columns="columns"
                  :dataSource="moreData"
                  style="padding: 14px 0;"
                >
                  <span slot="customTitle">Action Title</span>
                  <a slot="actionTitle" slot-scope="text" href="javascript:;">{{
                    text
                  }}</a>

                  <span
                    slot="dueDate"
                    slot-scope="text"
                    :class="
                      new Date(text) >= new Date('Jul 22, 2018')
                        ? 'red'
                        : 'grey'
                    "
                  >
                    {{ text }}
                  </span>

                  <span slot="status" slot-scope="text">
                    <a-tag :color="text === 'Assigned' ? 'green' : 'grey'">
                      {{ text }}
                    </a-tag>
                  </span>
                  <span
                    slot="priority"
                    slot-scope="text"
                    :class="
                      text === 'High'
                        ? 'red'
                        : text === 'Medium'
                        ? 'orange'
                        : 'green'
                    "
                  >
                    {{ text }}
                  </span>

                  <span slot="action" align="center">
                    <a-dropdown>
                      <a-menu slot="overlay">
                        <a-menu-item key="1"
                          ><a-icon type="edit" />Edit action</a-menu-item
                        >
                        <a-menu-item key="2"
                          ><a-icon type="download" />Save as
                          template</a-menu-item
                        >
                        <a-menu-item key="3"
                          ><a-icon type="copy" />Clone</a-menu-item
                        >
                        <a-menu-item key="4" class="red"
                          ><a-icon type="delete" />Delete</a-menu-item
                        >
                      </a-menu>

                      <a-icon type="ellipsis" />
                    </a-dropdown>
                  </span>
                </a-table>
              </a-tab-pane>
              <a-tab-pane tab="Action Plans" key="2" forceRender
                >Action Plans</a-tab-pane
              >
            </a-tabs>
          </a-layout-content>
        </a-layout>
      </a-layout-content>
      <a-layout-footer style="text-align: center"> </a-layout-footer>
    </a-layout>
  </div>
</template>

<script>
// @ is an alias to /src
//import HelloWorld from "@/components/HelloWorld.vue";

const columns = [
  {
    title: "Action ID",
    dataIndex: "actionID",
    key: "actionID"
  },
  {
    dataIndex: "actionTitle",
    key: "actionTitle",
    slots: { title: "customTitle" },
    scopedSlots: { customRender: "actionTitle" }
  },
  {
    title: "Created on",
    dataIndex: "created",
    key: "created"
  },
  {
    title: "Creator",
    dataIndex: "creator",
    key: "creator"
  },
  {
    title: "Due Date",
    dataIndex: "dueDate",
    key: "dueDate",
    scopedSlots: { customRender: "dueDate" }
  },
  {
    title: "Status",
    dataIndex: "status",
    key: "status",
    scopedSlots: { customRender: "status" }
  },
  {
    title: "Priority",
    dataIndex: "priority",
    key: "priority",
    scopedSlots: { customRender: "priority" }
  },

  /*   {
    title: "Tags",
    key: "tags",
    dataIndex: "tags",
    scopedSlots: { customRender: "tags" }
  }, */
  {
    title: "Action",
    key: "action",
    scopedSlots: { customRender: "action" }
  }
];

const data = [
  {
    key: "1",
    actionID: "ACT00032423",
    actionTitle: "The action title goes here...",
    created: "Jan 23, 2018 4:38 PM",
    creator: "Zac Mccoy",
    dueDate: "Feb 14, 2018",
    status: "Assigned",
    priority: "High",
    tags: ["nice", "developer"]
  },
  {
    key: "2",
    actionID: "ACT00032423",
    actionTitle: "A different title",
    created: "Jul 23, 2018 4:38 PM",
    creator: "Eleanor Fox",
    dueDate: "Feb 14, 2018",
    status: "Assigned",
    priority: "Medium",
    tags: ["nice", "developer"]
  },
  {
    key: "3",
    actionID: "ACT00032423",
    actionTitle: "Yet another title",
    created: "Apr 23, 2018 4:38 PM",
    creator: "Nathan Black",
    dueDate: "Sep 14, 2018",
    status: "Deleted",
    priority: "Low",
    tags: ["nice", "developer"]
  }
];

export default {
  data() {
    return {
      data,
      columns,
      moreData: []
    };
  },
  created() {
    for (let i = 0; i < 100; i++) {
      let random = Math.floor(Math.random() * 3);
      random.toString();
      let action = {
        key: i,
        actionID: this.data[random].actionID,
        actionTitle: this.data[random].actionTitle,
        created: this.data[random].created,
        creator: this.data[random].creator,
        dueDate: this.data[random].dueDate,
        status: this.data[random].status,
        priority: this.data[random].priority
      };
      this.moreData.push(action);
    }

    console.log(this.moreData);
  }
};
</script>
<style>
.min-h-100 {
  min-height: 100vh;
  display: flex;
}

.ml-auto {
  margin-left: auto;
}

.p-0 {
  padding: 0;
}

.logo {
  width: 50px;
}

.home {
  width: 100%;
}

h2 {
  display: inline-block;
  margin: 0;
}

.ant-layout-header,
.ant-menu-dark,
.ant-menu-dark .ant-menu-sub {
  background: #1890ff;
}

.ant-menu-dark.ant-menu-horizontal {
  display: flex;
}

.ant-table-pagination.ant-pagination {
  padding: 0 20px;
  margin-top: 40px;
}

.red {
  color: red;
}

.orange {
  color: orange;
}

.green {
  color: #52c41a;
}
</style>
